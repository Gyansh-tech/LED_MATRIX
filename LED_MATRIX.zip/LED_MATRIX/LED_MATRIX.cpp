#include "LED_MATRIX.h"
#include <math.h>

//the opcodes for the MAX7221 and MAX7219
#define OP_NOOP 0
#define OP_DIGIT0 1
#define OP_DIGIT1 2
#define OP_DIGIT2 3
#define OP_DIGIT3 4
#define OP_DIGIT4 5
#define OP_DIGIT5 6
#define OP_DIGIT6 7
#define OP_DIGIT7 8
#define OP_DECODEMODE 9
#define OP_INTENSITY 10
#define OP_SCANLIMIT 11
#define OP_SHUTDOWN 12
#define OP_DISPLAYTEST 15

LED_MATRIX::LED_MATRIX(int dataPin, int clkPin, int csPin, int numDevices) {
  SPI_MOSI = dataPin;
  SPI_CLK = clkPin;
  SPI_CS = csPin;
  NDevices = numDevices;
  if (numDevices <= 0 || numDevices > 8)
    numDevices = 8;
  maxDevices = numDevices;
  pinMode(SPI_MOSI, OUTPUT);
  pinMode(SPI_CLK, OUTPUT);
  pinMode(SPI_CS, OUTPUT);
  digitalWrite(SPI_CS, HIGH);
  SPI_MOSI = dataPin;
  for (int i = 0; i < 64; i++)
    status[i] = 0x00;
  for (int i = 0; i < maxDevices; i++) {
    spiTransfer(i, OP_DISPLAYTEST, 0);
    //scanlimit is set to max on startup
    setScanLimit(i, 7);
    //decode is done in source
    spiTransfer(i, OP_DECODEMODE, 0);
    clearDisplay(i);
    //we go into shutdown-mode on startup
    shutdown(i, true);
  }
}

int LED_MATRIX::getDeviceCount() {
  return maxDevices;
}

void LED_MATRIX::shutdown(int addr, bool b) {
  if (addr < 0 || addr >= maxDevices)
    return;
  if (b)
    spiTransfer(addr, OP_SHUTDOWN, 0);
  else
    spiTransfer(addr, OP_SHUTDOWN, 1);
}

void LED_MATRIX::setScanLimit(int addr, int limit) {
  if (addr < 0 || addr >= maxDevices)
    return;
  if (limit >= 0 && limit < 8)
    spiTransfer(addr, OP_SCANLIMIT, limit);
}

void LED_MATRIX::setIntensity(int addr, int intensity) {
  if (addr < 0 || addr >= maxDevices)
    return;
  if (intensity >= 0 && intensity < 16)
    spiTransfer(addr, OP_INTENSITY, intensity);
}

void LED_MATRIX::clearDisplay(int addr) {
  int offset;

  if (addr < 0 || addr >= maxDevices)
    return;
  offset = addr * 8;
  for (int i = 0; i < 8; i++) {
    status[offset + i] = 0;
    spiTransfer(addr, i + 1, status[offset + i]);
  }
}

// void LedControl::setLed(int addr, int row, int column, boolean state) {
//     int offset;
//     byte val=0x00;

//     if(addr<0 || addr>=maxDevices)
//         return;
//     if(row<0 || row>7 || column<0 || column>7)
//         return;
//     offset=addr*8;
//     val=B10000000 >> column;
//     if(state)
//         status[offset+row]=status[offset+row]|val;
//     else {
//         val=~val;
//         status[offset+row]=status[offset+row]&val;
//     }
//     spiTransfer(addr, row+1,status[offset+row]);
// }
////
void LED_MATRIX::setLed(int addr, int row, int column, boolean state) {
  int offset;
  byte val = 0x00;

  if (addr < 0 || addr >= maxDevices)
    return;
  if (row < 0 || row > 7 || column < 0 || column > 7)
    return;
  offset = addr * 8;
  val = 0b10000000 >> column;  // changed B10000000 → 0b10000000
  if (state)
    status[offset + row] = status[offset + row] | val;
  else {
    val = ~val;
    status[offset + row] = status[offset + row] & val;
  }
  spiTransfer(addr, row + 1, status[offset + row]);
}


void LED_MATRIX::setRow(int addr, int row, byte value) {
  int offset;
  if (addr < 0 || addr >= maxDevices)
    return;
  if (row < 0 || row > 7)
    return;
  offset = addr * 8;
  status[offset + row] = value;
  spiTransfer(addr, row + 1, status[offset + row]);
}

void LED_MATRIX::setColumn(int addr, int col, byte value) {
  byte val;

  if (addr < 0 || addr >= maxDevices)
    return;
  if (col < 0 || col > 7)
    return;
  for (int row = 0; row < 8; row++) {
    val = value >> (7 - row);
    val = val & 0x01;
    setLed(addr, row, col, val);
  }
}
void LED_MATRIX::setDigit(int addr, int digit, byte value, boolean dp) {
  int offset;
  byte v;

  if (addr < 0 || addr >= maxDevices)
    return;
  if (digit < 0 || digit > 7 || value > 15)
    return;
  offset = addr * 8;
  v = pgm_read_byte_near(charTable + value);
  if (dp)
    v |= 0b10000000;  // changed b10000000 → 0b10000000
  status[offset + digit] = v;
  spiTransfer(addr, digit + 1, v);
}

void LED_MATRIX::setChar(int addr, int digit, char value, boolean dp) {
  int offset;
  byte index, v;

  if (addr < 0 || addr >= maxDevices)
    return;
  if (digit < 0 || digit > 7)
    return;
  offset = addr * 8;
  index = (byte)value;
  if (index > 127) {
    //no defined beyond index 127, so we use the space char
    index = 32;
  }
  v = pgm_read_byte_near(charTable + index);
  if (dp)
    v |= 0b10000000;  // changed B10000000 → 0b10000000
  status[offset + digit] = v;
  spiTransfer(addr, digit + 1, v);
}


void LED_MATRIX::spiTransfer(int addr, volatile byte opcode, volatile byte data) {
  //Create an array with the data to shift out
  int offset = addr * 2;
  int maxbytes = maxDevices * 2;

  for (int i = 0; i < maxbytes; i++)
    spidata[i] = (byte)0;
  //put our device data into the array
  spidata[offset + 1] = opcode;
  spidata[offset] = data;
  //enable the line
  digitalWrite(SPI_CS, LOW);
  //Now shift out the data
  for (int i = maxbytes; i > 0; i--)
    shiftOut(SPI_MOSI, SPI_CLK, MSBFIRST, spidata[i - 1]);
  //latch the data onto the display
  digitalWrite(SPI_CS, HIGH);
}


void LED_MATRIX::begin() {
  int devices = getDeviceCount();
  for (int address = 0; address < devices; address++) {
    shutdown(address, false);
    setIntensity(address, 8);
    clearDisplay(address);
  }
}


void LED_MATRIX::drawDigit(int digit, int matrix) {
  clearDisplay(matrix);
  for (int row = 0; row < 8; row++) {
    setRow(matrix, row, digitFont8x8[digit][row]);
  }
}

int LED_MATRIX::getLetterPos(char Letter) {
  Letter = Letter - 'A';
  return (Letter);
}

double LED_MATRIX::getRemainder(double divisor, double dividend) {
  return (int)(divisor - (dividend * floor(divisor / dividend)));
}

void LED_MATRIX::drawNumber(int num, bool dp_present, int dp) {
  clear();
  if (num == 0) {
    drawDigit(0, 0);
  }
  int ndigit = 0;
  int check = num;
  while (check > 0) {
    check /= 10;
    ndigit += 1;
  }
  ndigit -=1;
  for(int i = 0; i <= ndigit; i++){
    if(i == 0){
      drawDigit(num%10, i);
    }else{
      int digit = getRemainder((num/pow(10,i)),10);
      drawDigit(digit,i);
    }
  }
  if (dp_present == true && dp < ndigit && dp != 0) {
    toggle_LED(dp,7,7,true);
  } else if(dp_present == true && (dp >= NDevices || dp == 0)){
    Serial.print("The Decimal Point Cannot be Drawn as it is greater than the capability of the library");
  }
  return;
}


void LED_MATRIX::drawLetter(char letter, int matrix) {
  clearDisplay(matrix);
  int letterPos = getLetterPos(letter);
  for (int row = 0; row < 8; row++) {
    setRow(matrix, row, Alphabet[letterPos][row]);
  }
}
void LED_MATRIX::reverseArray(char arr[]) {
  int start = 0;
  int end = NDevices - 1;
  while (start < end) {
    // Swap the elements at start and end positions
    char temp = arr[start];   // Store the start element temporarily
    arr[start] = arr[end];   // Replace the start element with the end element
    arr[end] = temp;         // Replace the end element with the stored temporary value

    // Move the pointers towards the center
    start++;
    end--;
  }
}

void LED_MATRIX::draw_Word(char Word[]) {
  char DisplayArray[8];
  for(int i = 0; i <= NDevices-1; i++){
    if(Word[i] != '\0' || Word[i] != ' '){
      DisplayArray[i] = Word[i];
    }else{
      DisplayArray[i] == ' ';
      if(Word[i] == '\0'){
        for(int x = i; x <= NDevices-1; x++){
          DisplayArray[x] = ' ';
        }
        break;
      }
    }
  }
  reverseArray(DisplayArray);
  for(int i = 0; i <= NDevices-1; i++){
    clearDisplay(i);
    drawLetter(DisplayArray[i],i);
  }
}

void LED_MATRIX::drawByte(byte Symbol[], int matrix) {
  for (int i = 0; i < 8; i++) {
    setRow(matrix, i, Symbol[i]);
  }
}

void LED_MATRIX::draw_RedLight() {
  for (int i = 0; i < NDevices; i++) {
    clearDisplay(i);
    for (int row = 0; row < 8; row++) {
      setRow(i, row, Redlight[row]);
    }
  }
}

void LED_MATRIX::draw_Crosses() {
  for (int i = 0; i < NDevices; i++) {
    clearDisplay(i);
    for (int row = 0; row < 8; row++) {
      setRow(i, row, fail[row]);
    }
  }
}

void LED_MATRIX::clear() {
  for (int i = 0; i < NDevices; i++) {
    clearDisplay(i);
  }
}

void LED_MATRIX::clear(int matrix) {
  clearDisplay(matrix);
}

void LED_MATRIX::setBrightness(int matrix, int brightness) {
  int const_bright = constrain(brightness, 0, 15);
  int const_matrix = constrain(matrix, 0, NDevices);
  setIntensity(const_matrix, const_bright);
}

void LED_MATRIX::set_collective_brightness(int brightness) {
  int const_bright = constrain(brightness, 0, 15);
  for (int i = 0; i < NDevices; i++) {
    setIntensity(i, const_bright);
  }
}

void LED_MATRIX::toggle_LED(int matrix, int row, int column, bool state) {
  setLed(matrix, row, column, state);
}

void LED_MATRIX::turnOff() {
  for (int i = 0; i < NDevices; i++) {
    shutdown(i, true);
  }
}

void LED_MATRIX::turnOff(int matrix) {
  shutdown(matrix, true);
}
